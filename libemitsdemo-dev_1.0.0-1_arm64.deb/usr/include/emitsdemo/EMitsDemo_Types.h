
#ifndef DATAMODEL_H
#define DATAMODEL_H

#define DEBUG
#ifdef DEBUG
#define DEBUG_PRINT(msg) std::cout << "throw exception: " << __FILE__ << ":" << __LINE__ << " [" << __func__ << "] " << msg << std::endl
#else
#define DEBUG_PRINT(msg)
#endif

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_FILENAME_LEN 1024
#define MAX_AUXS_CONUT 512
#define MAX_CHAR_CONUT 128

enum EMitsFileType
{
    Schedule,
    CANBMS,
    SMB,
    Simulation,
    BatterySimulation,
    TestObject,
    Chart
};

typedef enum EMitsResultType
{
    EMITS_RESULT_SUCCESS = 0,
    EMITS_RESULT_FAIL = 1,
    EMITS_RESULT_TIMEOUT = 2,
    EMITS_RESULT_USERNAME_PWD_ERROR = 3,
    EMITS_RESULT_FILE_EXIST_DIFF = 4,
    EMITS_RESULT_FILE_EXIST_SAME = 5,
    EMITS_RESULT_FILE_NOT_EXIST = 6,
    EMITS_RESULT_NOLOGIN = 7,
    EMITS_RESULT_BUF_NOT_ENOUGH = 8
} EMitsResultType;

enum EMitsParamType
{
    /*UnitCount,
    IVCount*/
};

struct ChanAuxsMap
{
    int ChannelID = 0;
    int Voltage = 0;
    int Temperature = 0;
    int Pressure = 0;
    int ExternalCharge = 0;
    int SMB = 0;
    int AO = 0;
    int DI = 0;
    int DO = 0;
    int Humidity = 0;
    int Current = 0;
    int Safety = 0;
    int CANBMS = 0;
};
struct ChannelResumeData
{
    int ChannelID = -1;
    int TestID = -1;
	char TestNames[512];//������������ö��ŷָ�
    char ScheduleName[512];
    int StepID = -1;
    int SubStepID = -1;
    int CycleID = -1;
    double TestTime = 0.0;
    double StepTime = 0.0;
    double ChargeCapacity = 0.0;
    double DischargeCapacity = 0.0;
    double ChargeEnergy = 0.0;
    double DischargeEnergy = 0.0;
    double TC_Time1 = 0.0;
    double TC_Time2 = 0.0;
    double TC_Time3 = 0.0;
    double TC_Time4 = 0.0;
    double TC_ChargeCapacity1 = 0.0;
    double TC_ChargeCapacity2 = 0.0;
    double TC_DishargeCapacity1 = 0.0;
    double TC_DishargeCapacity2 = 0.0;
    double TC_ChargeEnergy1 = 0.0;
    double TC_ChargeEnergy2 = 0.0;
    double TC_DischargeEnergy1 = 0.0;
    double TC_DischargeEnergy2 = 0.0;
    float TC_Counter1 = 0.0f;
    float TC_Counter2 = 0.0f;
    float TC_Counter3 = 0.0f;
    float TC_Counter4 = 0.0f;
    float TC_Counter5 = 0.0f;
    float TC_Counter6 = 0.0f;
    float TC_Counter7 = 0.0f;
    float TC_Counter8 = 0.0f;
    double ChargeCapacityTime = 0.0;
    double DischargeCapacityTime = 0.0;
    double MVUD1 = 0.0;
    double MVUD2 = 0.0;
    double MVUD3 = 0.0;
    double MVUD4 = 0.0;
    double MVUD5 = 0.0;
    double MVUD6 = 0.0;
    double MVUD7 = 0.0;
    double MVUD8 = 0.0;
    double MVUD9 = 0.0;
    double MVUD10 = 0.0;
    double MVUD11 = 0.0;
    double MVUD12 = 0.0;
    double MVUD13 = 0.0;
    double MVUD14 = 0.0;
    double MVUD15 = 0.0;
    double MVUD16 = 0.0;
};

struct AuxsData
{
    char AuxType[MAX_CHAR_CONUT];
    int AuxChGlobalID = -1;
    int AuxChVirtualID = -1;
    double Value = 0.0;
    double dxdt = 0.0;
};

struct ChannelMonitorData
{
    double ACI = 0.0;
    double ACIPhase = 0.0;
    double ACR = 0.0;
    AuxsData Auxs[MAX_AUXS_CONUT];
    char Barcode[MAX_CHAR_CONUT];
    char CANBMSName[MAX_CHAR_CONUT];
    //std::vector<int> CANs;
    //std::vector<int> CellDatas;
    int ChannelID = 0;
    double ChargeCapacity = 0.0;
    double ChargeEnergy = 0.0;
    char ChartName[MAX_CHAR_CONUT];
    bool CommunicationFailure = false;
    double Current = 0.0;
    double CurrentMaxOfTestObject = 0.0;
    int CycleID = 0;
    double DNC = 0.0;
    double DNLC = 0.0;
    double DischargeCapacity = 0.0;
    double DischargeEnergy = 0.0;
    //std::vector<int> EQDatas;
    char ExitCondition[MAX_CHAR_CONUT];
    char ID[MAX_CHAR_CONUT];
    double InternalResistance = 0.0;
    bool IsAutoCalculateOfTestObject = false;
    //std::vector<double> MVUDs; // ��ֵ��ѹ���ݣ�16����
    double MassOfTestObject = 0.0;
    int MasterChannelID = 0;
    double NominalCapacitanceOfTestObject = 0.0;
    double NominalCapacityOfTestObject = 0.0;
    double NominalIROfTestObject = 0.0;
    double NominalVoltageOfTestObject = 0.0;
    double Power = 0.0;
    char SMBName[MAX_CHAR_CONUT];
    //std::vector<int> SMBs;
    char SN[MAX_CHAR_CONUT];
    char ScheduleName[MAX_CHAR_CONUT];
    double SpecificCapacityOfTestObject = 0.0;
    char Status[MAX_CHAR_CONUT];
    char StepAndCycle[MAX_CHAR_CONUT];
    int StepID = 0;
    double StepTime = 0.0;
    //std::vector<int> SubChannels;
    int SubStepID = -1;
    int TaskID = 0;
    char TestName[MAX_CHAR_CONUT];
    char TestObjectName[MAX_CHAR_CONUT];
    double TestTime = 0.0;
    //std::vector<int> UDSDatas;
    double Voltage = 0.0;
    double VoltageMaxOfTestObject = 0.0;
    double VoltageMinOfTestObject = 0.0;
    double dQdV = 0.0;
    double dVdQ = 0.0;
    double dVdt = 0.0;
};

typedef void (*pOnChannelMonitorData)(ChannelMonitorData data);

#ifdef __cplusplus
}
#endif


#endif //DATAMODEL_H