﻿// EMitsDemo_ARM64.h: 公共头，导出库接口

#pragma once

#if defined(_WIN32) || defined(__CYGWIN__)
  #ifdef EMITS_EXPORTS
    #define EMITS_API __declspec(dllexport)
  #else
    #define EMITS_API __declspec(dllimport)
  #endif
#else
  #if __GNUC__ >= 4
    #define EMITS_API __attribute__ ((visibility ("default")))
  #else
    #define EMITS_API
  #endif
#endif

#include "EMitsDemo_Types.h"
#include <cstring>

#ifdef __cplusplus
extern "C" {
#endif

EMITS_API const char* EMitsDemo_GetVersion();
EMITS_API const char* EMitsDemo_GetLastReceiveJsonMsg();
EMITS_API EMitsResultType EMitsDemo_Connect(const char* server_ip, int timeout_ms);
EMITS_API void EMitsDemo_Disconnect();
EMITS_API EMitsResultType EMitsDemo_Login(const char* username, const char* password);
EMITS_API EMitsResultType EMitsDemo_CheckFile(const char* file_path);
EMITS_API EMitsResultType EMitsDemo_UploadFile(const char* local_path);
EMITS_API EMitsResultType EMitsDemo_BrowseFile(EMitsFileType fileType, char out_filenames[][MAX_FILENAME_LEN], int* out_count, int max_count);
EMITS_API EMitsResultType EMitsDemo_AssignFile(EMitsFileType fileType, const char* fileName, int chan[], int chan_count);
EMITS_API EMitsResultType EMitsDemo_GetMappingAux(ChanAuxsMap chanMap[], int* out_count, int max_count);

EMITS_API EMitsResultType EMitsDemo_StartChannel(ChannelResumeData chan[], int chan_count);
EMITS_API EMitsResultType EMitsDemo_StopChannel(int chan[], int chan_count);

EMITS_API void EMitsDemo_SetOnChannelMonitorData(pOnChannelMonitorData pfunc);

#ifdef __cplusplus
}
#endif
